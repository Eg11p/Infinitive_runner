var car, carImg;
var car2, carImg2;
var street, streetImg;
var obstacles, obstaclesImg, obstacleGroup;
var trophies, trophiesImg, trophiesGroup;
var gameState = "Play";
var Score;

function preload(){
    //Cargo las imagenes
    carImg = loadImage("car.png");
    carImg2 = loadImage("car2.jpeg");
    streetImg = loadImage("street.png");
    obstaclesImg = loadImage("obstacles.png");
    trophiesImg = loadImage("trophies.jpeg");

}

function setup() {
createCanvas(600,600);

    //Declaro las variables
    car = createSprite(300,250,20,20);
    car.addImage(carImg);
    street = createSprite(300,300);
    street.addImage(streetImg);

    //Declaro los grupos
    obstacleGroup = new Group();
    trophiesGroup = new Group();

    Score = 0;
}

function draw() {
    background(200);

    textSize(15);
    tex("Score: " + Score,550,50);

 if(gameState === "Play"){
    car.x = World.mouseX;
    car.y = World.mouseY;

if(obstaclesGroup.isTouching(car)){
    car.destroy();
    obstaclesGroup.destroyEach();
    trophiesGroup.destroyEach();
    street.destroyEach();
    gameState = "End";
}

if(trophiesGroup.isTouching(car)){
   Score = Score + 1;
}

   spawnObstacles();
   spawnTrophies();
 }
 if(gameState === "End"){
     stroke("black");
     fill("black");
     textSize(25);
    text("¡GAME OVER!",250,300);
    car2 = createSprite(200,200,20,20)
    car2.addImage(carImg2);
 }
 

 drawSprites();
}

function spawnObstacles(){
    if(frameCount % 60 === 0){
    obstacles = createSprite(500,150,20,20);
    obstacles.velocityY = 5;
    obstacles.addImage(obstaclesImg);
    obstacles.x = Math.round(random(140,400));
    obstacles.lifetime = 610;
    obstaclesGroup.add(obstacles);
    }
}

function spawnTrophies(){
    if(frameCount % 60 === 0){
        trophies = createSprite(300,-50);
        trophies.velocityY = 5;
        trophies.addImage(trophiesImg);
        trophies.x = Math.round(random(140,400));
        trophies.lifetime = -610;
        trophiesGroup.add(trophies);
    }
}